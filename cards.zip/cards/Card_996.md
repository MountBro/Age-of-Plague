#Card_996

Cost: 1

<<<<<<< HEAD
Description: The next 2 rounds, economy doubles, but the death rate rises 2%.
=======
Description: The next 2 rounds, economy temporarily doubles, but the death rate permanently rises 5%.
>>>>>>> 09f2ce7eff536eccfb7a5fac8e160af6d180d9ee
Action:
    resource
        economy
    population
        infected

//996 shi ni shang bei zi xiu lai de fu qi.
