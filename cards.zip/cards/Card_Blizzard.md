#Card_Blizzard

Cost: 8

Description: Freeze the spread of viruses spread for 3 rounds.

Action:
    virus
        freeze

//True power of the weather control device.