#Card_CellBroadcast

Cost: 4

Description: Select a tile. Attract 1 population from each neighboring tile.
Action:
    population
        flow

//Build a cohesive community.