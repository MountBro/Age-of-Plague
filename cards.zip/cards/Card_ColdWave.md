#Card_ColdWave

Cost: 1

Description: There is a probability of 50% to freeze the spread of viruses spread for 1 round.

Action:
    virus
        freeze

//Probably the most cost-effective card.