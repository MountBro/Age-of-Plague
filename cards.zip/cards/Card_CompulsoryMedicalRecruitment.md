#Card_CompulsoryMedicalRecruitment

Cost: 6

Description: Immediately summoned two [5] MegaCut cards.

Action:
    summon_card

//Medical personnel are the most scarce resources.