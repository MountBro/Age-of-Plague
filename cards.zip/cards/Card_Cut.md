#Card_Cut

Cost: 1

Description: Cut one hex.

Action:
    virus
        cut

//Basic skill in the post-apocalyptic world.