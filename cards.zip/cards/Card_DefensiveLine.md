#Card_DefensiveLine

Cost: 2

Description: Select a tile. Froze the spread of viruses for 2 rounds.

Action:
    virus
        froze

//The nanoviruses can build establish a line of defense to stop viruses.