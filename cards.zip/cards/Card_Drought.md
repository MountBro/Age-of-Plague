#Card_Drought

Cost: 2

Description: Choose a tile, in two rounds, the viruses have a probability of 50% to die. The economy output halves for two rounds.

Action:
    virus
        cut
    resource
        economy

//Drought devastates agricultural economy.