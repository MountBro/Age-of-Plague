#Card_EnhancedHealing

Cost: 4

Description: Slightly raise the efficiency of hospital healing (+1).
Action:
    tile
        hospital

//The forefront of the war.