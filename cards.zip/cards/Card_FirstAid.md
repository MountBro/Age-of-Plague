#Card_FirstAid

Cost: 2

Description: Summon one hospital card.

Action:
    summon_card

//The forefront of the war.