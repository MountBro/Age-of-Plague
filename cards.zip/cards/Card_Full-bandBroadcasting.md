#Card_Full-bandBroadcasting

Cost: 3

Description: Shift 2 population to a chosen direction for each tile
Action:
    population
        flow

//Great migration.