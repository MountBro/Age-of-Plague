#Card_GoingViral

Cost: 8

Description: Select a tile. Release the nano-viruses, which move randomly for 3 rounds and have a "cut" effect.

Action:
    GnerateAnti-virus

//Nanoviruses learn the behavior pattern of viruses.