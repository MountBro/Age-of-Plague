#Card_Hospital

Cost: 4

Description: Put a hospital on a tile
Action:
    tile
        hospital

//The forefront of the war.