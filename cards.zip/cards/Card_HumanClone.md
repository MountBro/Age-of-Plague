#Card_HumanClone

Cost: 2

Description: Double the population of a certain tile.
Action:
    population
        overall

//Human clone is not a taboo anymore.