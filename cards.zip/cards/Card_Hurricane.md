#Card_Hurricane

Cost: 6

Description: Translate all viruses two tiles to a chosen direction.

Action:
    virus
        translation

//We have developed immunity to airborne viruses.