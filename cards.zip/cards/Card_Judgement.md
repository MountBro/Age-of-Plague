#Card_Judgement

Cost: 6

Description: Select a tile. For each hex on and around the tile, either the people or the viruses die. The probability is 50%.

Action:
    virus
        cut
    population
        overall

//Great power comes at a cost.