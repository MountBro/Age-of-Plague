#Card_LowSoundWaves

Cost: 4

Description: Select a tile. Distribute all population to neighboring tiles.
Action:
    population
        flow

//By broadcasting low sound waves, we can drive the citizens away from the severly infected region.