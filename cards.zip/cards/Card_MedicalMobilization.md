#Card_MedicalMobilization

Cost: 6

Description: Immediately summoned three [1] Cut cards.

Action:
    summon_card

//Medical personnel are the most scarce resources.