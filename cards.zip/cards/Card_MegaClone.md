#Card_MegaClone:

Cost: 8

Description: The whole population x1.25.

Action:
    population
        overall

//Reborn.