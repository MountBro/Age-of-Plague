#Card_MegaCut
<<<<<<< HEAD

=======
>>>>>>> 09f2ce7eff536eccfb7a5fac8e160af6d180d9ee
Cost: 5

Description: Cut one tile.

Action:
    virus
        cut

<<<<<<< HEAD
//Basic skill in the post-apocalyptic world.
=======
//Basic skill in the post-apocalyptic world.
>>>>>>> 09f2ce7eff536eccfb7a5fac8e160af6d180d9ee
