#Card_OrganClone

Cost: 3

Description: Select a tile. Each one of the dead could save one infected.
Action:
    population
        infected

//A better tomorrow.