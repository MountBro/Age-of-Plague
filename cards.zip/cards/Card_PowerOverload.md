#Card_PowerOverload

Cost: 0

Description: +3 power, next round -3 power.
Action:
    Resource
        power
//Power generators need cooling after overload.
