#Card_Purification

Cost: 3

Description: Heal all patients in a certain tile.

Action:
    population
        infected

//Make good use of medical resources.