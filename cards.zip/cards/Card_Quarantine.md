#Card_Quarantine

Cost: 4

Description: Put one tile in quarantine

Action:
    tile
        quarantine

//The quarantine is efficent infrasturcture to keep people from viruses.