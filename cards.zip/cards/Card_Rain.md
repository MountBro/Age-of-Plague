#Card_Rain

Cost: 3

Description: In two rounds, there is a probability of 50% to freeze the spread of viruses for 1 round. The economy output doubles for two rounds.

Action:
    virus
        freeze
    resource
        economy

//Rain boosts agricultural economy.