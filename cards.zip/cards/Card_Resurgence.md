#Card_Resurgence

Cost: 8

Description: For each tile, restore 20% of the dead.
Action:
    population
        dead
        healthy

//Mercy of death.