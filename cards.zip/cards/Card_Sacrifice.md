#Card_Sacrifice

Cost: 4

Description: Select a tile. Kill both the viruses and the infected people.

Action:
    virus
        cut
    population
        infected

//Indiscriminate attack.