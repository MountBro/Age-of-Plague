#Card_Warehouse

Cost: 4

Description: Put a warehouse on a tile, +20 economy per round.
Action:
    resource
        economy

//Easy to collect.