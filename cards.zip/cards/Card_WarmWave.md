#Card_WarmWave

Cost: 1

Description: Choose a tile. There is a probability of 25% to kill the viruses.

Action:
    virus
        cut

//Probably the least cost-effective card.